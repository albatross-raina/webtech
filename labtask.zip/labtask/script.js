let events = [];

function addEvent() {

    let eventName = document.getElementById("event").value.trim();


    if (eventName === "") {
        alert("Please enter an event name.");
        return;
    }

    if (events.length >= 3) {
        alert("You can join a maximum of 3 events.");
        return;
    }

    events.push(eventName);


    document.getElementById("event").value = "";


    let eventList = document.getElementById("eventList");

    eventList.innerHTML = "";

    for (let i = 0; i < events.length; i++) {
        let li = document.createElement("li");

        li.textContent = events[i];

        eventList.appendChild(li);
    }

    alert("Event Added");
}


function confirmRegistration() {

    let studentName = document.getElementById("studentName").value.trim();


    if (studentName === "") {
        alert("Please enter your name.");
        return;
    }

 
    if (events.length === 0) {
        alert("Please add at least one event.");
        return;
    }

    localStorage.setItem("studentName", studentName);


    localStorage.setItem("events", JSON.stringify(events));

 
    window.location.href = "confirm.html";
}